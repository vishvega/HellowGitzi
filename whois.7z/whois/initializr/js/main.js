$( document ).ready(function() {
    // console.log( "ready!" );
    $("#getipdata-btn").click(function(e) {
		e.preventDefault();

		var getIP = $("input#getipvalue").val();
		console.log( getIP );
		var dataString = getIP;

		$.ajax({
			type: "POST",
			url: "../spy.php",
			data: dataString,
			success: function() {
				$('#getipvalue').val('');
				$('#ipdata').html("<h2>Contact Form Submitted!</h2>")
				.append("<p>processing...</p>")
				.hide()
				.fadeIn(1500, function() {
					$('#ipdata').append("<p>We will be in touch soon.eeeeeeeeee</p>");
				});
			}
		});
		return false;

    });
});
